self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ab02a3e9b3fa2548c33db685a6a12d49",
    "url": "/music/index.html"
  },
  {
    "revision": "4bdbc5d52f061f03580856efcf084229",
    "url": "/music/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/music/robots.txt"
  },
  {
    "revision": "5b79a36243155979de23",
    "url": "/music/static/css/app.f8629c73.css"
  },
  {
    "revision": "9b89fcfd860915612f01282e3a95bcaa",
    "url": "/music/static/img/default.9b89fcfd.png"
  },
  {
    "revision": "5b79a36243155979de23",
    "url": "/music/static/js/app.7d2f8a8e.js"
  },
  {
    "revision": "ecdf554a17b48340c4ef",
    "url": "/music/static/js/chunk-vendors.50ddec33.js"
  }
]);